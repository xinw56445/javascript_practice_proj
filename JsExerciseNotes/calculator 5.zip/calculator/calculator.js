// "use strict";
/*###########################################################*/

window.onload = function () {
    let _ce,
        _del,
        _leftBracket,
        _rightBracket,
        _0,
        _1,
        _2,
        _3,
        _4,
        _5,
        _6,
        _7,
        _8,
        _9,
        _plus,
        _minus,
        _multiply,
        _divide,
        _point,
        _equalTo,
        _lastResult,
        _resultDisplay;
    /**********************************计算结果展示**************************************/
    _resultDisplay = document.getElementById("calculation-results");
    /**********************************功能键 退格 清零 左右括号***************************/
    _ce = document.getElementById("clear-btn");
    _ce.addEventListener("click", function () {
        if (_resultDisplay.innerText.length >= 0) {
            _resultDisplay.innerText = "0";
        }
    });
    _del = document.getElementById("backspace");
    _del.addEventListener("click", function () {
        if (_resultDisplay.innerText.length === 1) {
            return _resultDisplay.innerText = "0";
        }
        else {
            let value = _resultDisplay.innerText.substring(0, _resultDisplay.innerText.length - 1);
            _resultDisplay.innerText = value;
        }
    });
    _leftBracket = document.getElementById("bracket-left");
    _leftBracket.addEventListener("click", function () {
        if (_resultDisplay.innerText === "0") {
            return _resultDisplay.innerText = "("
        }
        else {
            let result = _resultDisplay.innerText.concat("(");
            _resultDisplay.innerText = result;
        }
    });
    _rightBracket = document.getElementById("bracket-right");
    _rightBracket.addEventListener("click", function () {
        if (_resultDisplay.innerText === "0") {
            return _resultDisplay.innerText = ")"
        }
        else {
            let result = _resultDisplay.innerText.concat(")");
            _resultDisplay.innerText = result;
        }
    });
    /*************************************数字键 0～9**********************************/
    try {
        if (_resultDisplay.innerText.length > 15) {
            alert("超出最大输入范围！")
            return true
        }
        else {
            _0 = document.getElementById("num_0");
            _0.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0" || _resultDisplay.innerText === "") {
                    return _resultDisplay.innerText = "0";
                } else if (_resultDisplay.innerText === "0.") {
                    return _resultDisplay.innerText = _resultDisplay.innerText.concat("0");
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "0";
                } else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("0");
                }
            });
            _1 = document.getElementById("num_1");
            _1.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "1";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "1";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("1");
                }
            });
            _2 = document.getElementById("num_2");
            _2.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "2";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "2";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("2");
                }
            });
            _3 = document.getElementById("num_3");
            _3.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "3";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "3";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("3");
                }
            });
            _4 = document.getElementById("num_4");
            _4.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "4";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "4";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("4");
                }
            });
            _5 = document.getElementById("num_5");
            _5.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "5";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "5";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("5");
                }
            });
            _6 = document.getElementById("num_6");
            _6.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "6";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "6";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("6");
                }
            });
            _7 = document.getElementById("num_7");
            _7.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "7";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "7";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("7");
                }
            });
            _8 = document.getElementById("num_8");
            _8.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "8";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "8";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("8");
                }
            });
            _9 = document.getElementById("num_9");
            _9.addEventListener("click", function () {
                if (_resultDisplay.innerText === "0") {
                    return _resultDisplay.innerText = "9";
                } else if (
                    _resultDisplay.innerText.search("`") !== -1
                ) {
                    return _resultDisplay.innerText = "9";
                }
                else {
                    _resultDisplay.innerText = _resultDisplay.innerText.concat("9");
                }
            });
        }
    } catch (error) {
        _resultDisplay.innerHTML = error.message;
    }
    /*****************************************小数点*********************************/
    _point = document.getElementById("point");
    _point.addEventListener("click", function () {
        if (_resultDisplay.innerText === "0") {
            return _resultDisplay.innerText = "0.";
        } else if (_resultDisplay.innerText.substring(_resultDisplay.innerText.length - 1) !== ".") {
            return _resultDisplay.innerText = _resultDisplay.innerText.concat(".");
        } else if (_resultDisplay.innerText.substring(_resultDisplay.innerText.length - 1) === ".") {
            return true
        } else if (
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/\+/g) !== -1) ||
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/-/g) !== -1) ||
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/x/g) !== -1) ||
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/\//g) !== -1) ||
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/\(/g) !== -1) ||
            (_resultDisplay.innerText.indexOf(".") === 1 && _resultDisplay.innerText.search(/\)/g) !== -1)
        ) {
            _resultDisplay.innerText = _resultDisplay.innerText.concat(".");
        }
    });
    /*********************************运算符键盘***********************************************/
    _plus = document.getElementById("btn_add");
    _plus.addEventListener("click", function () {
        if (
            _resultDisplay.innerHTML.lastIndexOf("+") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("-") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("x") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("/") === _resultDisplay.innerHTML.length - 1
        ) {
            let new_text =
                _resultDisplay.innerHTML.replace(_resultDisplay.innerHTML.charAt(_resultDisplay.innerHTML.length - 1), "+");
            _resultDisplay.innerHTML = new_text;
        } else if (_resultDisplay.innerHTML.search('`') !== -1) {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.replace("`", "+");
        } else {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.concat("+");
        }
    });
    _minus = document.getElementById("btn_subtract");
    _minus.addEventListener("click", function () {
        if (
            _resultDisplay.innerHTML.lastIndexOf("+") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("-") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("x") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("/") === _resultDisplay.innerHTML.length - 1
        ) {
            let new_text =
                _resultDisplay.innerHTML.replace(_resultDisplay.innerHTML.charAt(_resultDisplay.innerHTML.length - 1), "-");
            _resultDisplay.innerHTML = new_text;
        } else if (_resultDisplay.innerHTML.search('`') !== -1) {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.replace("`", "-");
        } else {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.concat("-");
        }
    });
    _multiply = document.getElementById("btn_multiply");
    _multiply.addEventListener("click", function () {
        if (
            _resultDisplay.innerHTML.lastIndexOf("+") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("-") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("x") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("/") === _resultDisplay.innerHTML.length - 1
        ) {
            let new_text =
                _resultDisplay.innerHTML.replace(_resultDisplay.innerHTML.charAt(_resultDisplay.innerHTML.length - 1), "x");
            _resultDisplay.innerHTML = new_text;
        } else if (_resultDisplay.innerHTML.search('`') !== -1) {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.replace("`", "x");
        } else {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.concat("x");
        }
    });
    _divide = document.getElementById("btn_divide");
    _divide.addEventListener("click", function () {
        if (
            _resultDisplay.innerHTML.lastIndexOf("+") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("-") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("x") === _resultDisplay.innerHTML.length - 1 ||
            _resultDisplay.innerHTML.lastIndexOf("/") === _resultDisplay.innerHTML.length - 1
        ) {
            let new_text =
                _resultDisplay.innerHTML.replace(_resultDisplay.innerHTML.charAt(_resultDisplay.innerHTML.length - 1), "/");
            _resultDisplay.innerHTML = new_text;
        } else if (_resultDisplay.innerHTML.search('`') !== -1) {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.replace("`", "/");
        } else {
            _resultDisplay.innerHTML = _resultDisplay.innerHTML.concat("/");
        }
    });
    /*********************************计算结果***********************************************/
    const set_error = () => {  // 表达式错误自动归零
        function result(time, message) {
            return new Promise(function (resolve, reject) {
                setTimeout(function () {
                    console.log(message);
                    resolve(message);
                }, time);
            });
        }

        async function asyncFunc() {
            _resultDisplay.innerHTML = await result(100, 'Error');
            _resultDisplay.innerHTML = await result(1000, '0');
        };
        asyncFunc();
    }
    _lastResult = document.getElementById("last-result");
    _equalTo = document.getElementById("final-result");
    _equalTo.addEventListener("click", function () {
        let finalResult = _resultDisplay.innerHTML
        if ((finalResult.search(/\(/g) !== -1) && (finalResult.search(/\)/g) !== -1)) {  // 过滤括号
            if (finalResult.indexOf("(") < finalResult.indexOf(")")) {
                let textInParentheses;  // 括号中的文本
                textInParentheses = finalResult.substring(finalResult.indexOf("(") + 1, finalResult.indexOf(")"));
                if (textInParentheses !== "") {
                    if (textInParentheses.indexOf("+") !== 0 ||
                        textInParentheses.indexOf("-") !== 0 ||
                        textInParentheses.indexOf("x") !== 0 ||
                        textInParentheses.indexOf("/") !== 0
                    ) {
                        if (finalResult.search(/x/g) !== -1) {
                            finalResult = finalResult.replace(/x/g, "*");
                        }
                        _lastResult.innerText = finalResult + " =";
                        _resultDisplay.innerText = eval(finalResult);
                    } else {
                        set_error();
                        return _resultDisplay;
                    }
                } else {
                    set_error();
                    return _resultDisplay;
                }
            } else {
                set_error();
                return _resultDisplay;
            }
        } else {  // 没有括号
            if ( // 只有一半括号报错
                (finalResult.search(/\(/g) !== -1) && (finalResult.search(/\)/g) === -1) ||
                (finalResult.search(/\(/g) === -1) && (finalResult.search(/\)/g) !== -1)
            ) {
                set_error();
                return _resultDisplay;
            } else if ( // 最后一位是运算符则报错
                finalResult.lastIndexOf("+") === finalResult.length - 1 ||
                finalResult.lastIndexOf("-") === finalResult.length - 1 ||
                finalResult.lastIndexOf("x") === finalResult.length - 1 ||
                finalResult.lastIndexOf("/") === finalResult.length - 1
            ) {
                set_error();
                return _resultDisplay;
            } else {
                if (!isNaN(finalResult)) {
                    if (_lastResult.innerText.search(/\+/g) !== -1 || // 是数字且缓存结果有运算符
                    _lastResult.innerText.search(/-/g) !== -1 ||
                    _lastResult.innerText.search(/x/g) !== -1 ||
                    _lastResult.innerText.search(/\//g) !== -1
                    ) {
                        _lastResult.innerText = "Ans = " + eval(finalResult);
                    } else {
                        console.log("text 只有数字这一个条件")
                        _lastResult.innerText = finalResult + " =";
                    }
                    if (finalResult.search(/x/g) !== -1) {
                        finalResult = finalResult.replace(/x/g, "*");
                    }
                    return _resultDisplay.innerText = eval(finalResult) + "`";
                } else { // 输入不是数字
                    _lastResult.innerText = finalResult + " =";
                    if (finalResult.search(/x/g) !== -1) {
                        finalResult = finalResult.replace(/x/g, "*");
                    } else if (finalResult.search(/`/g) !== -1) {
                        finalResult = finalResult.substring(0, finalResult.indexOf("`"));
                        _lastResult.innerText = "Ans = " + eval(finalResult);
                    }
                    try {
                        let _value, _len;
                        _value = eval(finalResult);  // 预计算值
                        _len = _value.toString().length;
                        if ((_len > 15) && (parseInt(_value) !== parseFloat(_value))) {  // 预值是小数且.后位数大于15
                            let _float = parseFloat(_value).toFixed(10);
                            _float = parseFloat(_float);
                            return _resultDisplay.innerText = _float + "`";
                        }
                        _resultDisplay.innerText = eval(finalResult) + "`";
                    } catch (e) {
                        alert("Unknown Exception");
                    }
                }
            }
        }
    });
}
