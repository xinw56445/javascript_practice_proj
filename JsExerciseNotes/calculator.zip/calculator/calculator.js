// "use strict";
/*###########################################################*/

class Calculator {
    constructor(name) {
        this.name = name;
    }

    getBtnText(btnId) {

        return document.getElementById(btnId);
    }

    add() {

    }

}

let calculator = new Calculator("");
/**********************************功能键盘**************************************/
const clearText = () => {
    /* CE*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length >= 0) {
        document.getElementById("calculation-results").innerText = 0;
    }
};

const bracketLeft = () => {
    /* 左括号*/
    let text = document.getElementById("calculation-results").innerText;
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "("
    }
    document.getElementById("calculation-results").innerText = text.concat("(");
};

const bracketRight = () => {
    /* 右括号*/
    let text = document.getElementById("calculation-results").innerText;
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = ")"
    }
    document.getElementById("calculation-results").innerText = text.concat(")");
};

const backSpace = () => {
    /* DEL*/
    let result = document.getElementById("calculation-results").innerText;
    if (result.length === 1) {
        return document.getElementById("calculation-results").innerText = 0;
    }
    document.getElementById("calculation-results").innerText = result.substring(0, result.length - 1);
};
/***************************************数字键盘**********************************************/
const btn_one = () => {
    /* 1*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "1";
    }
    document.getElementById("calculation-results").innerText = text.concat("1");
};

const btn_two = () => {
    /* 2*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "2";
    }
    document.getElementById("calculation-results").innerText = text.concat("2");
};

const btn_three = () => {
    /* 3*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "3";
    }
    document.getElementById("calculation-results").innerText = text.concat("3");
};

const btn_four = () => {
    /* 4*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "4";
    }
    document.getElementById("calculation-results").innerText = text.concat("4");
};

const btn_five = () => {
    /* 5*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "5";
    }
    document.getElementById("calculation-results").innerText = text.concat("5");
};

const btn_six = () => {
    /* 6*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "6";
    }
    document.getElementById("calculation-results").innerText = text.concat("6");
};

const btn_seven = () => {
    /* 7*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "7";
    }
    document.getElementById("calculation-results").innerText = text.concat("7");
};

const btn_eight = () => {
    /* 8*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "8";
    }
    document.getElementById("calculation-results").innerText = text.concat("8");
};

const btn_nine = () => {
    /* 9*/
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "9";
    }
    document.getElementById("calculation-results").innerText = text.concat("9");
};

const btn_zero = () => {
    /* 0*/
    let text;
    text = document.getElementById("calculation-results").innerText;
    if (text.length > 15) {
        alert("超出最大输入范围！")
        return true
    }
    if (text === "0" || text === "") {
        return document.getElementById("calculation-results").innerText = "0";
    } else if (text === "0.") {
        return document.getElementById("calculation-results").innerText = text.concat("0")
    } else {
        document.getElementById("calculation-results").innerText = text.concat("0");
    }
};
/**************point********************/
const btn_point = () => {
    /* .*/
    let text = document.getElementById("calculation-results").innerText;
    if (text === "0") {
        return document.getElementById("calculation-results").innerText = "0.";
    } else if (
        (text.indexOf(".") === 1 && text.search(/\+/g)) ||
        (text.indexOf(".") === 1 && text.search(/-/g)) ||
        (text.indexOf(".") === 1 && text.search(/x/g)) ||
        (text.indexOf(".") === 1 && text.search(/\//g)) ||
        (text.indexOf(".") === 1 && text.search(/\(/g)) ||
        (text.indexOf(".") === 1 && text.search(/\)/g))
    ) {
        document.getElementById("calculation-results").innerText = text.concat(".");
    } else if (text.indexOf(".") === 1) {
        return true
    } else {
        document.getElementById("calculation-results").innerText = text.concat(".");
    }
};

/*********************************运算符键盘***********************************************/
const add = () => {
    /* 运算符 + */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "+");
        document.getElementById("calculation-results").innerText = new_text;
    } else {
        document.getElementById("calculation-results").innerText = text.concat("+");
    }
};
// Add, subtract, multiply, divide
const subtract = () => {
    /* 运算符 - */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "-");
        document.getElementById("calculation-results").innerText = new_text;
    } else {
        document.getElementById("calculation-results").innerText = text.concat("-");
    }
};
const multiply = () => {
    /* 运算符 * */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "x");
        document.getElementById("calculation-results").innerText = new_text;
    } else {
        document.getElementById("calculation-results").innerText = text.concat("x");
    }
};
const divide = () => {
    /* 运算符 / */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "/");
        document.getElementById("calculation-results").innerText = new_text;
    } else {
        document.getElementById("calculation-results").innerText = text.concat("/");
    }
};

const getResult = {
    /**
     * 恢复对象
     */
    result: "0",
    display: function () {
        let text = document.getElementById("calculation-results");
        text.innerText = this.result;  // 在display 方法中，this指的是getResult对象
    }
}
let get_result = getResult.display.bind(getResult);

const calculation_results = () => {
    /* 计算结果*/
    let text, textValue, resultValue;
    text = document.getElementById("calculation-results").innerText;
    textValue = document.getElementById("calculation-results");
    resultValue = document.getElementById("last-result");
    if ((text.search(/\(/g) !== -1) && (text.search(/\)/g) !== -1)) {  // 过滤括号
        if (text.indexOf("(") < text.indexOf(")")) {
            let textInParentheses;  // 括号中的文本
            textInParentheses = text.substring(text.indexOf("(") + 1, text.indexOf(")"));
            if (textInParentheses !== "") {
                if (textInParentheses.indexOf("+") !== 0 ||
                    textInParentheses.indexOf("-") !== 0 ||
                    textInParentheses.indexOf("x") !== 0 ||
                    textInParentheses.indexOf("/") !== 0
                ){
                    // console.log("代码执行到这里了" + textInParentheses)
                    if (text.search(/x/g) !== -1) {
                        text = text.replace(/x/g, "*");
                        // let new_text = text.replace(/\((.*?)\)/g, eval(textInParentheses));
                    }
                    textValue.innerText = eval(text);
                    resultValue.innerText = "Ans = " + eval(text);
                } else {
                    textValue.innerText = "Error";
                    setTimeout(get_result, 1000);
                    return textValue;
                }
            } else {
                textValue.innerText = "Error";
                setTimeout(get_result, 1000);
                return textValue;
            }
        } else {
            textValue.innerText = "Error";
            setTimeout(get_result, 1000);
            return textValue;
        }
    } else {
        if (
            (text.search(/\(/g) !== -1) && (text.search(/\)/g) === -1) ||
            (text.search(/\(/g) === -1) && (text.search(/\)/g) !== -1)
        ) {
            textValue.innerText = "Error";
            setTimeout(get_result, 1000);
            return textValue;
        } else if (
            text.lastIndexOf("+") === text.length -1 ||
            text.lastIndexOf("-") === text.length -1 ||
            text.lastIndexOf("x") === text.length -1 ||
            text.lastIndexOf("/") === text.length -1
        ){
            textValue.innerText = "Error";
            setTimeout(get_result, 1000);
            return textValue;
        } else {
            // console.log("没有括号")
            textValue.innerText = eval(text);
            resultValue.innerText = "Ans = " + eval(text);
        }
    }
}