// "use strict";
/*###########################################################*/

class Calculator {
    constructor(name) {
        this.name = name;
    }

    getBtnText(btnId) {
        return document.getElementById(btnId);
    }

    add() {}

}

let calculator = new Calculator("");
/**********************************功能键盘**************************************/
const clearText = () => {
    /* CE*/
    let text = document.getElementById("calculation-results");
    if (text.innerText.length >= 0) {
        text.innerText = 0;
    }
};

const bracketLeft = () => {
    /* 左括号*/
    let text, result;
    text = document.getElementById("calculation-results");
    if (text.innerText === "0") {
        return text.innerText = "("
    }
    result = text.innerText.concat("(");
    text.innerText = result;
};

const bracketRight = () => {
    /* 右括号*/
    let text, result;
    text = document.getElementById("calculation-results");
    if (text.innerText === "0") {
        return text.innerText = ")"
    }
    result = text.innerText.concat(")");
    text.innerText = result;
};

const backSpace = () => {
    /* DEL*/
    let result, value;
    result = document.getElementById("calculation-results");
    if (result.innerText.length === 1) {
        return result.innerText = "0";
    }
    value = result.innerText.substring(0, result.innerText.length - 1);
    document.getElementById("calculation-results").innerText = value;
};

/***************************************数字键盘**********************************************/

function input_restrictions() {
    /**
     * 输入范围控制函数
     * @type {string}
     */
    let text = document.getElementById("calculation-results").innerText;
    if (text.length > 10) {
        alert("超出最大输入范围！")
        return true
    }
}

const setResult = {
    /**
     * 数据重置对象
     */
    result: "0",
    display: function () {
        let text = document.getElementById("calculation-results");
        text.innerText = this.result;  // 在display 方法中，this指的是getResult对象
    }
}
let set_result = setResult.display.bind(setResult);

const TEXT_ = () => document.getElementById("calculation-results");
const VALUE_ = () => TEXT_().innerText;
const flag_ = () => {
    return VALUE_().search("`") !== -1;

}
const btnOne = () => {
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "1";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "1";
    }
    TEXT_().innerText = VALUE_().concat("1");
};

const btnTwo = () => {
    /* 2*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "2";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "2";
    }
    TEXT_().innerText = VALUE_().concat("2");
};

const btnThree = () => {
    /* 3*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "3";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "3";
    }
    TEXT_().innerText = VALUE_().concat("3");
};

const btnFour = () => {
    /* 4*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "4";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "4";
    }
    TEXT_().innerText = VALUE_().concat("4");
};

const btnFive = () => {
    /* 5*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "5";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "5";
    }
    TEXT_().innerText = VALUE_().concat("5");
};

const btnSix = () => {
    /* 6*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "6";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "6";
    }
    TEXT_().innerText = VALUE_().concat("6");
};

const btnSeven = () => {
    /* 7*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "7";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "7";
    }
    TEXT_().innerText = VALUE_().concat("7");
};

const btnEight = () => {
    /* 8*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "8";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "8";
    }
    TEXT_().innerText = VALUE_().concat("8");
};

const btnNine = () => {
    /* 9*/
    input_restrictions();
    if (VALUE_() === "0") {
        return TEXT_().innerText = "9";
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "9";
    }
    TEXT_().innerText = VALUE_().concat("9");
};

const btnZero = () => {
    /* 0*/
    input_restrictions();
    if (TEXT_().innerText === "0" || TEXT_().innerText === "") {
        return TEXT_().innerText = "0";
    } else if (TEXT_().innerText === "0.") {
        return TEXT_().innerText = TEXT_().innerText.concat("0");
    } else if (
        flag_()
    ) {
        return TEXT_().innerText = "0";
    } else {
        TEXT_().innerText = TEXT_().innerText.concat("0");
    }
};
/**************point********************/
const btn_point = () => {
    /* .*/
    let text = document.getElementById("calculation-results");
    if (text.innerText === "0") {
        return text.innerText = "0.";
    } else if (text.innerText.substring(text.innerText.length - 1) !== ".") {
        return text.innerText = text.innerText.concat(".");
    } else if (text.innerText.substring(text.innerText.length - 1) === ".") {
        return true
    } else if (
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/\+/g) !== -1) ||
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/-/g) !== -1) ||
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/x/g) !== -1) ||
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/\//g) !== -1) ||
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/\(/g) !== -1) ||
        (text.innerText.indexOf(".") === 1 && text.innerText.search(/\)/g) !== -1)
    ) {
        text.innerText = text.innerText.concat(".");
    }
};

/*********************************运算符键盘***********************************************/
const add = () => {
    /* 运算符 + */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "+");
        document.getElementById("calculation-results").innerText = new_text;
    } else if (text.search('`') !== -1) {
        TEXT_().innerText = text.replace("`", "+");
    } else {
        document.getElementById("calculation-results").innerText = text.concat("+");
    }
};
// Add, subtract, multiply, divide
const subtract = () => {
    /* 运算符 - */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "-");
        document.getElementById("calculation-results").innerText = new_text;
    } else if (text.search('`') !== -1) {
            TEXT_().innerText = text.replace("`", "-");
    } else {
        document.getElementById("calculation-results").innerText = text.concat("-");
    }
};
const multiply = () => {
    /* 运算符 * */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "x");
        document.getElementById("calculation-results").innerText = new_text;
    } else if (text.search('`') !== -1) {
        TEXT_().innerText = text.replace("`", "x");
    } else {
        document.getElementById("calculation-results").innerText = text.concat("x");
    }
};
const divide = () => {
    /* 运算符 / */
    let text, new_text;
    text = document.getElementById("calculation-results").innerText;
    if (
        text.lastIndexOf("+") === text.length - 1 ||
        text.lastIndexOf("-") === text.length - 1 ||
        text.lastIndexOf("x") === text.length - 1 ||
        text.lastIndexOf("/") === text.length - 1
    ) {
        new_text = text.replace(text.charAt(text.length - 1), "/");
        document.getElementById("calculation-results").innerText = new_text;
    } else if (text.search('`') !== -1) {
        TEXT_().innerText = text.replace("`", "/");
    } else {
        document.getElementById("calculation-results").innerText = text.concat("/");
    }
};

const calculation_results = () => {
    /* 计算结果*/
    let text, textValue, resultValue;
    text = document.getElementById("calculation-results").innerText;
    textValue = document.getElementById("calculation-results");
    resultValue = document.getElementById("last-result");
    if ((text.search(/\(/g) !== -1) && (text.search(/\)/g) !== -1)) {  // 过滤括号
        if (text.indexOf("(") < text.indexOf(")")) {
            let textInParentheses;  // 括号中的文本
            textInParentheses = text.substring(text.indexOf("(") + 1, text.indexOf(")"));
            if (textInParentheses !== "") {
                if (textInParentheses.indexOf("+") !== 0 ||
                    textInParentheses.indexOf("-") !== 0 ||
                    textInParentheses.indexOf("x") !== 0 ||
                    textInParentheses.indexOf("/") !== 0
                ) {
                    if (text.search(/x/g) !== -1) {
                        text = text.replace(/x/g, "*");
                        // let new_text = text.replace(/\((.*?)\)/g, eval(textInParentheses));
                    }
                    resultValue.innerText = text + " =";
                    textValue.innerText = eval(text);
                } else {
                    textValue.innerText = "Error";
                    setTimeout(set_result, 1000);
                    return textValue;
                }
            } else {
                textValue.innerText = "Error";
                setTimeout(set_result, 1000);
                return textValue;
            }
        } else {
            textValue.innerText = "Error";
            setTimeout(set_result, 1000);
            return textValue;
        }
    } else {  // 没有括号
        if ( // 只有一半括号报错
            (text.search(/\(/g) !== -1) && (text.search(/\)/g) === -1) ||
            (text.search(/\(/g) === -1) && (text.search(/\)/g) !== -1)
        ) {
            textValue.innerText = "Error";
            setTimeout(set_result, 1000);
            return textValue;
        } else if ( // 最后一位是运算符则报错
            text.lastIndexOf("+") === text.length - 1 ||
            text.lastIndexOf("-") === text.length - 1 ||
            text.lastIndexOf("x") === text.length - 1 ||
            text.lastIndexOf("/") === text.length - 1
        ) {
            textValue.innerText = "Error";
            setTimeout(set_result, 1000);
            return textValue;
        } else {
            if (!isNaN(text)) {
                if (resultValue.innerText.search(/\+/g) !== -1 || // 是数字且缓存结果有运算符
                    resultValue.innerText.search(/-/g) !== -1 ||
                    resultValue.innerText.search(/x/g) !== -1 ||
                    resultValue.innerText.search(/\//g) !== -1
                ) {
                    resultValue.innerText = "Ans = " + eval(text);
                } else {
                    console.log("text 只有数字这一个条件")
                    resultValue.innerText = text + " =";
                }
                if (text.search(/x/g) !== -1) {
                    text = text.replace(/x/g, "*");
                }
                return textValue.innerText = eval(text) + "`";
            } else { // 输入不是数字
                resultValue.innerText = text + " =";
                if (text.search(/x/g) !== -1) {
                    text = text.replace(/x/g, "*");
                }
                try {
                    let _value, _len;
                    _value = eval(text);  // 预计算值
                    _len = _value.toString().length;
                    if ((_len > 15) && (parseInt(_value) !== parseFloat(_value))) {  // 预值是小数且.后位数大于15
                        let _float = parseFloat(_value).toFixed(10);
                        _float = parseFloat(_float);
                        return textValue.innerText = _float + "`";
                    }
                    textValue.innerText = eval(text) + "`";
                } catch (e) {
                    alert("Unknown Exception");
                }
            }
        }
    }
}